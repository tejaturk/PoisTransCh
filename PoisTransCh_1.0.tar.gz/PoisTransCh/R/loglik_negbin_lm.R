loglik_negbin_lm <- function(beta, kappa, X, j, p, max_terms=Inf, tol=1e-32) {
  
  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # if p is the same for all chains
  if (length(p)==1) {
    p <- rep(p, nrow(X))
  }
  
  # calculate R0s: exp(x^T beta) for each row of B and k=e^kappa
  R0 <- exp(X%*%beta)
  k <- exp(kappa)
  
  # the S derivatives
  Sj <- mapply(FUN = function(rr, kk, jj, pp) S_j(j=jj, 
                                                  R0=rr,
                                                  k=kk,
                                                  p=pp, 
                                                  max_terms = max_terms, tol = tol),
               R0, k, j, p)
  # the factorials
  j_fac <- sapply(j, factorial)
  # the probability of observing a chain of size 0
  prob0 <- mapply(FUN = function(rr, kk, pp) S_j(j=0,
                                                 R0=rr,
                                                 k=kk,
                                                 p=pp, 
                                                 max_terms = max_terms, tol = tol),
                  R0, k, p)
  
  # the likelihood
  ll <- sum(log(Sj)-log(j_fac)-log(1-prob0))
  
  
  return(ll)
  
}