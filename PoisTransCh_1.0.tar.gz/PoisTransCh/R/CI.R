setGeneric("CI", function(mle_fit, alpha=0.95, method="Wald", pars=mle_fit@parameter_names) standardGeneric("CI"))

# mle_fit: object as returned from mle call
# alpha: significance level
# method: one from: Wald, likelihood, score (at the moment just Wald)
# pars: parameters of which the CI are calculated

setMethod("CI", signature(mle_fit="MLEfit", alpha="numeric", method="character", pars="character"),
          function(mle_fit, alpha, method, pars) {
            
            if (!(method %in% c("Wald"))) {
              stop("Currently implemented confidence interval methods is only 'Wald'.")
            }
            
            par_est <- c(mle_fit@coefficients$R0, mle_fit@coefficients$others)
            par_hat <- par_est[which(names(par_est) %in% pars)]
            FI_hat_full <- prof_I(mle_fit, free_pars = FALSE)
            FI_hat_full <- FI_hat_full(par_est)
            # in any case we need the Wald confidence intervals
            wald_ci <- CI_Wald(par_hat=par_hat, Fisher_info_hat = FI_hat_full, alpha = alpha)
            
            if (method=="Wald") {
              ci <- wald_ci
              attr(ci, "method") <- "Wald"
            }
            
            return(ci)
            
          })