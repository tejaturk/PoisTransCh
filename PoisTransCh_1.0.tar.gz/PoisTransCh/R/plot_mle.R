setGeneric("plot_mle", function(mle_fit, alpha=NULL) standardGeneric("plot_mle"))

# mle_fit: object as returned from mle call
# alpha: significance levels for the prediction intervals (if missing or not in [0,1] only the R0 is computed)

setMethod("plot_mle", signature(mle_fit="MLEfit", alpha="numeric"),
          function(mle_fit, alpha) {
            
            mle_ci <- R0(mle_fit=mle_fit, alpha=alpha)
            plot(mle_ci$Estimate, 1:nrow(mle_ci), pch=19, cex=0.6,
                 xlim=c(min(mle_ci$`2.5%`), max(mle_ci$`97.5%`)),
                 yaxt="n", xlab="R0 and factors", ylab="")
            axis(side=2, at=1:nrow(mle_ci), labels = row.names(mle_ci), las=1)
            segments(x0=mle_ci$`2.5%`, y0=1:nrow(mle_ci), x1=mle_ci$`97.5%`, y1=1:nrow(mle_ci), lty="solid")
            abline(v=1, col="gray", lty="dotted")
            text(x = mle_ci$`97.5%`[1], y=1, pos=4, labels = round(mle_ci$Estimate[1], digits=2), cex=0.5)
            
            return(mle_ci)
            
          })

setMethod("plot_mle", signature(mle_fit="MLEfit", alpha="missing"),
          function(mle_fit) {
            
            plot_mle(mle_fit = mle_fit, alpha = 0.95)
            
          })
