setGeneric("R0", function(mle_fit, new_data=NULL, alpha=NULL) standardGeneric("R0"))

# mle_fit: object as returned from mle call
# new_data: new data frame on which the R0 is calculated
# alpha: significance levels for the prediction intervals (if missing or not in [0,1] only the R0 is computed)

setMethod("R0", signature(mle_fit="MLEfit", new_data="data.frame", alpha="numeric"),
          function(mle_fit, new_data, alpha) {
            
            z <- qnorm((1+alpha)/2)
            
            # extract the beta coefficients
            beta <- mle_fit@coefficients$R0
            if (is.null(names(beta))) {
              names(beta) <- mle_fit@parameter_names[1:length(beta)]
            }
            
            # # get the predictions
            # # if the data frame is empty:
            # if (nrow(new_data) == 0) {
            #   R0_pred <- exp(beta)
            #   names(R0_pred) <- paste("exp(", names(beta), ")", sep="")
            #   # replace exp(log(...)) with ...
            #   names(R0_pred) <- gsub("exp\\(log\\((.*)\\)\\)", "\\1", names(R0_pred))
            # }
            # 
            # else {
            #   # extract the rhs formula
            #   formula <- reformulate(attr(delete.response(terms(mle_fit@formula)), "term.labels"))
            #   
            #   # prepare the new design matrix
            #   X_new <- model.matrix(formula, new_data)
            #   
            #   # evaluate the fit row-wise on the new data frame
            #   R0_pred <- exp(X_new%*%beta)
            #   R0_pred <- data.frame(R0=R0_pred)
            #   
            #   # join it with the new data set
            #   R0_pred <- cbind(new_data, R0_pred)
            # }
            # 
            # predicted_R0 <- R0_pred
            
            # to obtain the prediction errors we need the inverse of Fisher information matrix
            inv_I <- tryCatch(solve(mle_fit@Fisher_info(c(beta, mle_fit@coefficients$others))), error=function(e) e)
            if (inherits(inv_I, "error")) {
              inv_I <- MASS::ginv(mle_fit@Fisher_info(c(beta, mle_fit@coefficients$others)))
              dimnames(inv_I)[[1]] <- c(names(beta), names(mle_fit@coefficients$others))
              dimnames(inv_I)[[2]] <- c(names(beta), names(mle_fit@coefficients$others))
            }
            
            # for beta only the beta part is needed
            var_beta <- inv_I[names(beta), names(beta), drop=FALSE]
            
            # if the data frame is empty -> only the exp of the coefficients are calculated
            # and the prediction intervals are the confidence intervals on the exp scale
            # if the data frame is empty:
            if (nrow(new_data) == 0) {
              R0_pred <- exp(beta)
              names(R0_pred) <- paste("exp(", names(beta), ")", sep="")
              # replace exp(log(...)) with ...
              # names(R0_pred) <- gsub("exp\\(log\\((.*)\\)\\)", "\\1", names(R0_pred))
              pi <- mapply(FUN=function(ph, se) ph + c(-1, 1)*z*se,
                           beta, sqrt(diag(var_beta)), SIMPLIFY=FALSE)
              pi <- array(do.call(rbind, pi), dim=c(length(beta), 2))
              dimnames(pi)[[1]] <- as.list(names(R0_pred))
              dimnames(pi)[[2]] <- paste(round(c((1-alpha)/2, (1+alpha)/2)*100, digits=2), "%", sep="")
              R0_pred <- data.frame(Estimate=R0_pred, exp(pi[,1]), exp(pi[,2]))
              names(R0_pred) <- c("Estimate", dimnames(pi)[[2]])
              row.names(R0_pred) <- dimnames(pi)[[1]]
            }
            
            # else the prediction error of beta^T x is calculated first for each row of the design matrix
            else {
              
              # new_data has to have the same factor levels as the fitted data
              for (vn in names(new_data)) {
                if (is.factor(new_data[[vn]]) && length(grep(vn, attr(terms.formula(mle_fit@formula), "term.labels"))) > 0) {
                  new_data[[vn]] <- factor(new_data[[vn]], 
                                           levels=levels(mle_fit@data[[vn]]))
                }
              }
              # extract the rhs formula
              model_terms <- terms.formula(mle_fit@formula)
              if (length(attr(model_terms, "term.labels")) == 0) {
                formula <- ~1
              }
              else {
                formula <- reformulate(attr(delete.response(model_terms), "term.labels"),
                                       intercept=attr(model_terms, "intercept")==1)
              }
              
              # prepare the new design matrix
              X_new <- model.matrix(formula, new_data)
              
              # evaluate the fit row-wise on the new data frame
              R0_pred_log <- X_new%*%beta
              
              # calculate the prediction error for each row
              pred_err <- sapply(1:nrow(X_new), FUN=function(i) {
                x <- as.vector(X_new[i,,drop=FALSE])
                pe <- t(x) %*% var_beta %*% x
              })
              
              #finally get the prediction intervals
              pi <- mapply(FUN=function(r, pe) {
                exp(r + c(-1,1)*z*sqrt(pe))
              }, R0_pred_log, pred_err, SIMPLIFY = FALSE)
              
              pi <- data.frame(do.call(rbind, pi))
              
              R0_pred <- data.frame("R0"=exp(R0_pred_log), pi)
              names(R0_pred) <- c("R0", paste(round(c((1-alpha)/2, (1+alpha)/2)*100, digits=2), "%", sep=""))
              R0_pred <- cbind(new_data, R0_pred)
              row.names(R0_pred) <- dimnames(X_new)[[1]]
            }
            
            return(R0_pred)
            
          })

setMethod("R0", signature(mle_fit="MLEfit", new_data="data.frame", alpha="missing"),
          function(mle_fit, new_data) {
            
            return(R0(mle_fit = mle_fit, new_data = new_data, alpha = 0.95))
            
          })

setMethod("R0", signature(mle_fit="MLEfit", new_data="missing", alpha="numeric"),
          function(mle_fit, alpha) {
            
            return(R0(mle_fit = mle_fit, new_data = data.frame(), alpha = alpha))
            
          })

setMethod("R0", signature(mle_fit="MLEfit", new_data="missing", alpha="missing"),
          function(mle_fit) {
            
            return(R0(mle_fit = mle_fit, new_data = data.frame(), alpha = 0.95))
            
          })
