setGeneric("simulate_trans_ch", function(n, R0, k, rho, p, N_max, formula, data, coefficients, mle_fit) standardGeneric("simulate_trans_ch"))

setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="numeric", rho="numeric", p="numeric", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, k, rho, p, N_max) {
            
            # simulate negative binomial branching process
            sampleBranchingNegBin <- function(R0, k, rho, p, N_max) {
              
              column.names <- c("ID", "Generation", "NrTrans", "Source", "Observed")
              # adding the root node
              t <- 0
              x <- rnbinom(1, mu=rho*R0, size=k)
              obs <- runif(1, min=0, max=1)
              infected <- data.frame(1, t, x, 0, obs<=p)
              colnames(infected) <- column.names
              
              prevGen <- infected[which(infected$NrTrans > 0 & infected$Generation==t),]
              prevGenSize <- nrow(prevGen)
              while (t < N_max && prevGenSize > 0) {
                t <- t + 1
                newSize <- sum(prevGen$NrTrans)
                x <- rnbinom(newSize, mu=R0, size=k)
                newIDs <- seq(nrow(infected) + 1, length.out = newSize)
                newParents <- rep(prevGen$ID, prevGen$NrTrans)
                observed <- runif(newSize, min=0, max=1)
                newGen <- data.frame(newIDs, rep(t, times=newSize), x, newParents, observed <= p)
                colnames(newGen) <- column.names
                infected <- rbind(infected, newGen)
                prevGen <- infected[which(infected$NrTrans > 0 & infected$Generation==t),]
                prevGenSize <- nrow(prevGen)
              } 
              
              # what is the observed chain size?
              chain_size <- sum(infected$Observed)
              return(chain_size)
            }
            
            sim_chains <- replicate(n, sampleBranchingNegBin(R0=R0, k=k, rho=rho, p=p, N_max=N_max))
            sim_chains <- sim_chains[which(sim_chains>0)]
            sim_chains <- data.frame(chain_size=sim_chains)
            return(sim_chains)
            
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="missing", rho="numeric", p="numeric", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, rho, p, N_max) {
            
            # simulate poisson branching process
            sampleBranchingPois <- function(R0, rho, p, N_max) {
              
              column.names <- c("ID", "Generation", "NrTrans", "Source", "Observed")
              # adding the root node
              t <- 0
              x <- rpois(1, lambda=rho*R0)
              obs <- runif(1, min=0, max=1)
              infected <- data.frame(1, t, x, 0, obs<=p)
              colnames(infected) <- column.names
              
              prevGen <- infected[which(infected$NrTrans > 0 & infected$Generation==t),]
              prevGenSize <- nrow(prevGen)
              while (t < N_max && prevGenSize > 0) {
                t <- t + 1
                newSize <- sum(prevGen$NrTrans)
                x <- rpois(newSize, lambda=R0)
                newIDs <- seq(nrow(infected) + 1, length.out = newSize)
                newParents <- rep(prevGen$ID, prevGen$NrTrans)
                observed <- runif(newSize, min=0, max=1)
                newGen <- data.frame(newIDs, rep(t, times=newSize), x, newParents, observed <= p)
                colnames(newGen) <- column.names
                infected <- rbind(infected, newGen)
                prevGen <- infected[which(infected$NrTrans > 0 & infected$Generation==t),]
                prevGenSize <- nrow(prevGen)
              } 
              
              # what is the observed chain size?
              chain_size <- sum(infected$Observed)
              return(chain_size)
            }
            
            sim_chains <- replicate(n, sampleBranchingPois(R0=R0, rho=rho, p=p, N_max=N_max))
            sim_chains <- sim_chains[which(sim_chains>0)]
            sim_chains <- data.frame(chain_size=sim_chains)
            return(sim_chains)
            
          })


setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="numeric", rho="numeric", p="missing", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, k, rho, N_max) {
            p <- 1
            return(simulate_trans_ch(n=n, R0=R0, k=k, rho=rho, p=p))
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="missing", rho="numeric", p="missing", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, rho, N_max) {
            p <- 1
            return(simulate_trans_ch(n=n, R0=R0,  rho=rho, p=p))
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="numeric", rho="missing", p="numeric", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, k, p, N_max) {
            rho <- 1
            return(simulate_trans_ch(n=n, R0=R0, k=k, rho=rho, p=p))
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="missing", rho="missing", p="numeric", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, p, N_max) {
            rho <- 1
            return(simulate_trans_ch(n=n, R0=R0,  rho=rho, p=p))
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="numeric", rho="missing", p="missing", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, k, N_max) {
            rho <- 1
            p <- 1
            return(simulate_trans_ch(n=n, R0=R0, k=k, rho=rho, p=p))
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="numeric", k="missing", rho="missing", p="missing", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="missing"),
          function(n, R0, N_max) {
            rho <- 1
            p <- 1
            return(simulate_trans_ch(n=n, R0=R0,  rho=rho, p=p))
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="missing", k="missing", rho="numeric", p="numeric", N_max="numeric",
                                formula="formula", data="data.frame", coefficients="list", mle_fit="missing"),
          function(n, rho, p, N_max, formula, data, coefficients) {
            # for each data row we need R0, rho and p
            if (length(rho)==1) {
              rho <- rep(rho, times=nrow(data))
            }
            if (length(p)==1) {
              p <- rep(p, times=nrow(data))
            }
            # extract the beta coefficients
            beta <- coefficients$R0
            
            # extract response
            resp <- formula[[2]]
            
            # extract the rhs formula
            model_terms <- terms.formula(formula)
            if (length(attr(model_terms, "term.labels")) == 0) {
              formula <- ~1
            }
            else {
              formula <- reformulate(attr(delete.response(model_terms), "term.labels"),
                                     intercept=attr(model_terms, "intercept")==1)
            }
            
            # prepare the new design matrix
            X_new <- model.matrix(formula, data)
            data[[resp]] <- NULL
            
            # evaluate the fit row-wise on the new data frame
            R0_pred_log <- X_new%*%beta
            R0 <- exp(R0_pred_log)
            
            # simulated chains per row
            if (length(coefficients$others)>0) {
              k <- coefficients$others[1]
              sim_chains_per_row <- mapply(FUN=function(r, rr, pp) simulate_trans_ch(n=n, R0=r, k=k, rho=rr, p=pp, N_max=N_max),
                                           R0, rho, p,
                                           SIMPLIFY = FALSE)
            }
            else {
              sim_chains_per_row <- mapply(FUN=function(r, rr, pp) simulate_trans_ch(n=n, R0=r, rho=rr, p=pp, N_max=N_max),
                                           R0, rho, p,
                                           SIMPLIFY = FALSE)
            }
            sim_chains_per_row <- lapply(sim_chains_per_row, FUN=function(df) {
              names(df)[which(names(df)=="chain_size")] <- as.character(resp)
              df
              })
            sim_chains_per_row <- lapply(1:nrow(data), FUN=function(i) cbind(data[rep(i, times=nrow(sim_chains_per_row[[i]])),], 
                                                                             sim_chains_per_row[[i]]))
            sim_chains <- sim_chains_per_row
            # sim_chains <- do.call(rbind, sim_chains_per_row)
            
            return(sim_chains)
          })

setMethod("simulate_trans_ch", signature(n="numeric", R0="missing", k="missing", rho="missing", p="missing", N_max="numeric",
                                formula="missing", data="missing", coefficients="missing", mle_fit="MLEfit"),
          function(n, N_max, mle_fit) {
            rho <- mle_fit@rho
            p <- mle_fit@p
            formula <- mle_fit@formula
            data <- mle_fit@data
            coefficients <- mle_fit@coefficients
            
            return(simulate_trans_ch(n=n, N_max=N_max, rho=rho, p=p, formula=formula, data=data, coefficients=coefficients))
          })