chains_origin <- function(tree, sequences, nodes, model="JC69", ...) {
  
  chain_origin <- function(node) {
    N <- length(tree$tip.label)
    node <- as.integer(node)
    # extract the chain
    if (node <= N) {
      chain <- tree$tip.label[node]
    }
    else {
      chain <- ape::extract.clade(tree, node=node)$tip.label
    }
    
    # find the MRCA
    mrca <- tree$edge[which(tree$edge[,2]==node),1]
    
    # extract the closest neighbours
    history <- ape::extract.clade(tree, node=mrca)$tip.label
    
    # extract those not contained in the chain:
    origin <- setdiff(history, chain)
    origin <- origin[which(origin %in% labels(sequences))]
    
    if (length(origin) > 1) {
      # get the corresponding sequences
      chain_seq <- sequences[chain]
      origin_seq <- sequences[origin]
      
      # calculate the pairwise distances
      dist <- lapply(origin, FUN=function(or) {
        d <- array(unlist(
          lapply(chain, FUN=function(ch) {
            d <- ape::dist.dna(ape::as.DNAbin(ape::as.alignment(list(chain_seq[ch], origin_seq[or]))),
                               model=model)
          })), dim=c(1, length(chain)))
        d
      })
      dist <- array(do.call(rbind, dist), dim=c(length(origin), length(chain)))
      dimnames(dist)[[1]] <- origin
      dimnames(dist)[[2]] <- chain
      
      # origin is the one with the minimal pairwise distance:
      origin_seq <- origin[which(dist==min(dist), arr.ind = TRUE)[1]]
    }
    else if (length(origin)==0) {
      origin_seq <- NA
    }
    else {
      origin_seq <- origin
    }
    
    names(origin_seq) <- node
    return(origin_seq)
  }
  
  origin_chains <- sapply(nodes, FUN=chain_origin)
  
  origin_chains <- data.frame("chain_id"=nodes, "origin_chain"=origin_chains)
  row.names(origin_chains) <- NULL
  origin_chains$chain_id <- as.character(origin_chains$chain_id)
  origin_chains$origin_chain <- as.character(origin_chains$origin_chain)
  return(origin_chains)
}