loglik_negbin_1 <- function(beta, kappa, j, n_j, p, max_terms=Inf, tol=1e-32) {

  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # the probability generating function is defined for R0 = e^beta and k=e^kappa
  R0 <- exp(beta)
  k <- exp(kappa)
  
  # the S derivatives
  Sj <- sapply(j, S_j, R0=R0, k=k, p=p, max_terms=max_terms, tol=tol)
  # the factorials
  j_fac <- sapply(j, factorial)
  # the probability of observing a chain of size0
  prob0 <- S_j(j=0, R0=R0, k=k, p=p, max_terms=max_terms, tol=tol) 
  
  # the likelihood
  ll <- sum(n_j*(log(Sj)-log(j_fac)-log(1-prob0)))
  
  return(ll)
  
}