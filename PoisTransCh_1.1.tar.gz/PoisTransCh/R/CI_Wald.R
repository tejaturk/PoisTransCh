CI_Wald <- function(par_hat, Fisher_info_hat, alpha=0.95) {
  z <- qnorm((1+alpha)/2)
  
  # it can be defined for more parameters at once
  inv_FI <- solve(Fisher_info_hat)[names(par_hat), names(par_hat), drop=FALSE]
  diag_inv_FI <- diag(inv_FI)
  
  ci <- mapply(FUN=function(ph, se) ph + c(-1, 1)*z*se,
               par_hat, sqrt(diag_inv_FI), SIMPLIFY=FALSE)
  
  # return an array
  ci <- array(do.call(rbind, ci), dim=c(length(par_hat), 2))
  dimnames(ci)[[1]] <- as.list(names(par_hat))
  dimnames(ci)[[2]] <- paste(round(c((1-alpha)/2, (1+alpha)/2)*100, digits=2), "%", sep="")
  
  return(ci)
}