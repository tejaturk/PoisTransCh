lik_ratio <- function(mle1, mle2) {
  
  # which model is generalized and which nested?
  terms1 <- terms.formula(mle1@formula)
  terms1 <- c(attr(terms1, "term.labels"), if (attr(terms1, "intercept")==1) "(Intercept)" else c())
  
  terms2 <- terms.formula(mle2@formula)
  terms2 <- c(attr(terms2, "term.labels"), if (attr(terms2, "intercept")==1) "(Intercept)" else c())
  
  setdiff_1 <- setdiff(terms1, terms2)
  setdiff_2 <- setdiff(terms2, terms1)
  
  if (mle1@model==mle2@model) {
    if (length(setdiff_1) == 0) {
      mle_nested <- mle1
      mle_general <- mle2
      q <- length(setdiff_2)
    }
    else if (length(setdiff_2) == 0) {
      mle_nested <- mle2
      mle_general <- mle1
      q <- length(setdiff_1)
    }
    else {
      stop("One model should be nested within the other.", call. = FALSE)
    }
  }
  
  else {
    # Poisson has to be nested within the negative binomial
    if (mle1@model=="Poisson" && length(setdiff_1) == 0) {
      mle_nested <- mle1
      mle_general <- mle2
      q <- length(setdiff_2) + 1
    }
    else if (mle2@model=="Poisson" && length(setdiff_2) == 0) {
      mle_nested <- mle2
      mle_general <- mle1
      q <- length(setdiff_1) + 1
    }
    else {
      stop("One model should be nested within the other.", call. = FALSE)
    }

  }
  
  # loglik of both models at the MLE
  ll_nested <- mle_nested@loglik(unlist(mle_nested@coefficients))
  ll_general <- mle_general@loglik(unlist(mle_general@coefficients))
  
  # LR statistics
  W <- 2*(ll_general - ll_nested)
  attr(W, "q") <- q
  
  return(W)
  
}