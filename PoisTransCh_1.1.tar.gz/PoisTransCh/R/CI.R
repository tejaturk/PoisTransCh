setGeneric("CI", function(mle_fit, alpha=0.95, method="Wald", pars=mle_fit@parameter_names) standardGeneric("CI"))

# mle_fit: object as returned from mle call
# alpha: significance level
# method: one from: Wald, likelihood, score (at the moment just Wald)
# pars: parameters of which the CI are calculated

setMethod("CI", signature(mle_fit="MLEfit", alpha="numeric", method="character", pars="character"),
          function(mle_fit, alpha, method, pars) {
            
            if (!(method %in% c("Wald", "likelihood"))) {
              stop("Currently implemented confidence interval methods are 'Wald' and 'likelihood'.")
            }
            
            par_est <- c(mle_fit@coefficients$R0, mle_fit@coefficients$others)
            par_hat <- par_est[which(names(par_est) %in% pars)]
            FI_hat_full <- mle_fit@Fisher_info(par_est)
            # in any case we need the Wald confidence intervals
            wald_ci <- CI_Wald(par_hat=par_hat, Fisher_info_hat = FI_hat_full, alpha = alpha)
            
            if (method=="Wald") {
              ci <- wald_ci
              attr(ci, "method") <- "Wald"
            }
            
            else if (method=="likelihood") {
              ci <- CI_loglik(mle_fit=mle_fit, pars=pars, 
                              alpha=alpha, trace=FALSE, bands=wald_ci)
              attr(ci, "method") <- "likelihood"
            }
            
            return(ci)
            
          })

setMethod("CI", signature(mle_fit="MLEfit", alpha="numeric", method="missing", pars="character"),
          function(mle_fit, alpha, pars) {
            
            method <- "Wald"
            return(CI(mle_fit=mle_fit, alpha=alpha, method=method, pars=pars))
            
          })

setMethod("CI", signature(mle_fit="MLEfit", alpha="missing", method="character", pars="character"),
          function(mle_fit, method, pars) {
            
            alpha <- 0.95
            return(CI(mle_fit=mle_fit, alpha=alpha, method=method, pars=pars))
            
          })

setMethod("CI", signature(mle_fit="MLEfit", alpha="numeric", method="character", pars="missing"),
          function(mle_fit, alpha, method) {
            
            pars <- mle_fit@parameter_names
            return(CI(mle_fit=mle_fit, alpha=alpha, method=method, pars=pars))
            
          })

setMethod("CI", signature(mle_fit="MLEfit", alpha="numeric", method="missing", pars="missing"),
          function(mle_fit, alpha) {
            
            method <- "Wald"
            pars <- mle_fit@parameter_names
            return(CI(mle_fit=mle_fit, alpha=alpha, method=method, pars=pars))
            
          })

setMethod("CI", signature(mle_fit="MLEfit", alpha="missing", method="character", pars="missing"),
          function(mle_fit, method) {
            
            alpha <- 0.95
            pars <- mle_fit@parameter_names
            return(CI(mle_fit=mle_fit, alpha=alpha, method=method, pars=pars))
            
          })

setMethod("CI", signature(mle_fit="MLEfit", alpha="missing", method="missing", pars="character"),
          function(mle_fit, pars) {
            
            alpha <- 0.95
            method <- "Wald"
            return(CI(mle_fit=mle_fit, alpha=alpha, method=method, pars=pars))
            
          })

setMethod("CI", signature(mle_fit="MLEfit", alpha="missing", method="missing", pars="missing"),
          function(mle_fit) {
            
            alpha <- 0.95
            method <- "Wald"
            pars <- mle_fit@parameter_names
            return(CI(mle_fit=mle_fit, alpha=alpha, method=method, pars=pars))
            
          })