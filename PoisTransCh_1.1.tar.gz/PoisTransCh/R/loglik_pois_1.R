loglik_pois_1 <- function(beta, j, n_j, p, rho, max_terms=Inf, tol=1e-32) {

  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # the probability generating function is defined for lambda = e^beta
  lambda <- exp(beta)
  
  # the R derivatives
  Rj <- sapply(j, R_j, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the factorials
  #j_fac <- sapply(j, factorial)
  # log(j!)
  log_j_fac <- sapply(j, FUN=function(jj) log(sum(1:jj)))
  # the probability of observing a chain of size0
  prob0 <- R_j(j=0, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol) 
  
  # the likelihood
  ll <- sum(n_j*(log(Rj)-log_j_fac-log(1-prob0)))
  
  return(ll)
  
}