p_values_Wald_test <- function(par_hat, Fisher_info_hat, H_0=0, H_alter="equal") {
  
  # alternative hypotheses:
  # equal: H_A: beta_hat = beta_0
  # less: H_A: beta_hat < beta_0
  # greater: H_A: beta_hat > beta_0
  
  # if only one H_0 is specified -> take the same for all parameters in par_hat
  if (length(H_0) == 1) {
    H_0 <- rep(H_0, times=length(par_hat))
    names(H_0) <- names(par_hat)
  }
  else if (length(H_0) != length(par_hat)) {
    stop("The number of specified null hypotheses should be either 1 or 1 for each parameter.")
  }
  else if (is.null(names(H_0))) {
    names(H_0) <- names(par_hat)
  }
  else {
    H_0 <- H_0[names(par_hat)]
  }
  
  # checks for the alternative hypotheses
  if (length(H_alter) == 1) {
    H_alter <- rep(H_alter, times=length(par_hat))
    names(H_alter) <- names(par_hat)
  }
  else if (length(H_alter) != length(par_hat)) {
    stop("The number of specified alternative hypotheses types should be either 1 or 1 for each parameter.")
  }
  else if (!all(H_alter %in% c("equal", "less", "greater"))) {
    stop("Each alternative hypothesis can be one of the following: 'equal', 'greater' or 'less'!")
  }
  else if (is.null(names(H_alter))) {
    names(H_alter) <- names(par_hat)
  }
  else {
    H_alter <- H_alter[names(par_hat)]
  }
  
  # invert the Fisher information matrix for the specified parameters
  inv_FI <- tryCatch(solve(Fisher_info_hat)[names(par_hat), names(par_hat), drop=FALSE], error=function(e) e)
  if (inherits(inv_FI, "error")) {
    inv_FI <- MASS::ginv(Fisher_info_hat)
    dimnames(inv_FI)[[1]] <- dimnames(Fisher_info_hat)[[1]]
    dimnames(inv_FI)[[2]] <- dimnames(Fisher_info_hat)[[2]]
    inv_FI <- inv_FI[names(par_hat), names(par_hat), drop=FALSE]
  }
  # inv_FI <- solve(Fisher_info_hat)[names(par_hat), names(par_hat), drop=FALSE]
  diag_inv_FI <- diag(inv_FI)
  
  # get the test statistics for all the parameters
  t_test <- mapply(FUN=function(ph, se, ph0) (ph-ph0)/se, 
                   par_hat, sqrt(diag_inv_FI), H_0)
  names(t_test) <- names(par_hat)
  
  # function to calculate p-value
  p_val <- function(t, H_A) {
    if (H_A=="equal") {
      p <- 2*(1-pnorm(abs(t)))
    }
    else if (H_A=="less") {
      p <- pnorm(t)
    }
    else {
      p <- 1-pnorm(t)
    }
    return(p)
  }
  
  # calculate p-values for all the parameters:
  p_values <- mapply(FUN=function(t, H_A) p_val(t, H_A),
                     t_test, H_alter)
  names(p_values) <- names(par_hat)
  return(p_values)
}