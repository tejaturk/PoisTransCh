information_criterion <- function(theta_mle, loglik, nr_par, nr_obs) {
  
  ll_mle <- loglik(theta_mle)
  
  # Akaike information criterion: -2 l(theta_MLE) + 2*p
  aic <- -2*ll_mle + 2*nr_par
  
  # Bayesian information criterion: -2 l (theta_MLE) + p*log(n)
  bic <- -2*ll_mle + nr_par*log(nr_obs)
  
  ic <- list("AIC"=aic,
             "BIC"=bic)
  
  return(ic)
  
}