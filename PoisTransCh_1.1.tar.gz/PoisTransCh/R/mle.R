mle <- function(formula, data, p=1, rho=1, model="Poisson", par0=NULL, 
                h_1 = 1e-6, h_2 = 1e-4, method="BFGS",
                max_terms=Inf, tol_Taylor=1e-16,
                max_iter=Inf, tol=1e-7, trace=FALSE,
                tol_R0=1e-3) {
  

  stopifnot(model %in% c("Poisson", "NegativeBinomial"))
  
  # for C++
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # check the factors if each level occurs at least once
  for (vn in names(data)) {
    if (is.factor(data[[vn]])) {
      unique_val <- unique(data[[vn]])
      levels_var <- levels(data[[vn]])
      if (length(unique_val) < length(levels_var)) {
        new_levels <- levels_var[which(as.character(levels_var) %in% as.character(unique_val))]
        data[[vn]] <- factor(data[[vn]], 
                              levels = new_levels)
      }
    }
  }
  
  # lhs of the formula to get the chain sizes
  response <- formula[[2]]
  
  # chain sizes:
  j <- data[[as.character(response)]]
  
  # build the design matrix
  X <- model.matrix(formula, data)
  # if X has only intercept -> rename it to log(R0) or log(lambda)
  if (length(dimnames(X)[[2]])==1 && dimnames(X)[[2]][1] == "(Intercept)") {
    dimnames(X)[[2]][1] <- if (model=="Poisson") "log(lambda)" else "log(R0)"
  }
  
  # parameter names:
  beta.names <- dimnames(X)[[2]]
  par.names <- beta.names
  if (model=="NegativeBinomial") {
    par.names <- c(par.names, "log(k)")
  }
  
  # for negative binomial -> only rho = 1 is possible
  if (model=="NegativeBinomial") {
    rho <- 1
  }
  
  # is the model simple?
  simple.model <- FALSE
  if (dim(X)[2]==1 && unique(X)==1 && length(unique(p))==1 && length(unique(rho))==1) {
    simple.model <- TRUE
  }
  
  # if the model is simple, the parameter names are:
  if (simple.model && model=="Poisson") {
    par.names <- c("log(lambda)")
  }
  else if (simple.model && model=="NegativeBinomial") {
    par.names <- c("log(R0)", "log(k)")
  }
  
  # we need one p and one rho per if the model is not simple:
  # p:
  if (length(p) != nrow(data) && !simple.model) {
    p <- rep(p[1], nrow(data))
  }
  else if (length(p) != 1 && simple.model) {
    p <- unique(p)
  }
  # rho:
  if (length(rho) != nrow(data) && !simple.model) {
    rho <- rep(rho[1], nrow(data))
  }
  else if (length(rho) != 1 && simple.model) {
    rho <- unique(rho)
  }
  
  # likelihood and score function
  # if the model is simple:
  if (simple.model) {
    j <- table(j)
    n_j <- as.integer(j) # frequencies
    j <- as.integer(names(j)) # chain sizes in the compact form
    
    if (model=="Poisson") {
      # likelihood function, simple Poisson model
      ll <- function(par) {
        l <- loglik_pois_1(beta=par, j=j, n_j=n_j, p=p, rho=rho, 
                           max_terms=max_terms, tol=tol_Taylor)
        return(l)
      }
      # score function, simple Poisson model
      u <- function(par) {
        uu <- score_pois_1(beta=par, j=j, n_j=n_j, p=p, rho=rho, 
                           max_terms=max_terms, tol=tol_Taylor)
        return(uu)
      }
      # Fisher information matrix, simple Poisson model
      FI <- function(par) {
        ff <- Fisher_info_pois_1(beta=par, j=j, n_j=n_j, p=p, rho=rho, 
                           max_terms=max_terms, tol=tol_Taylor)
        dimnames(ff)[[1]] <- par.names
        dimnames(ff)[[2]] <- par.names
        return(ff)
      }
    }
    else {
      # likelihood function, simple negative binomial model
      ll <- function(par) {
        par.beta <- par[1]
        par.k <- par[2]
        l <- loglik_negbin_1(beta=par.beta, kappa=par.k, j=j, n_j=n_j, p=p, 
                             max_terms=max_terms, tol=tol_Taylor)
        return(l)
      }
      # score function, simple negative binomial model
      u <- function(par) {
        par.beta <- par[1]
        par.k <- par[2]
        uu <- score_negbin_1(beta=par.beta, kappa=par.k, j=j, n_j=n_j, p=p, 
                             h=h_1,
                             max_terms=max_terms, tol=tol_Taylor)
        return(uu)
      }
      # Fisher information matrix, simple negative binomial model
      FI <- function(par) {
        par.beta <- par[1]
        par.k <- par[2]
        ff <- Fisher_info_negbin_1(beta=par.beta, kappa=par.k, j=j, n_j=n_j, p=p, 
                             h_1=h_1, h_2=h_2,
                             max_terms=max_terms, tol=tol_Taylor)
        dimnames(ff)[[1]] <- par.names
        dimnames(ff)[[2]] <- par.names
        return(ff)
      }
    }
    
  }
  else {
    if (model=="Poisson") {
      # likelihood function, Poisson model with regression
      ll <- function(par) {
        l <- loglik_pois_lm(beta=par, X=X, j=j, p=p, rho=rho, 
                           max_terms=max_terms, tol=tol_Taylor)
        return(l)
      }
      # score function, Poisson model with regression
      u <- function(par) {
        uu <- score_pois_lm(beta=par, X=X, j=j, p=p, rho=rho, 
                            max_terms=max_terms, tol=tol_Taylor)
        return(uu)
      }
      # Fisher information matrix, Poisson model with regression
      FI <- function(par) {
        ff <- Fisher_info_pois_lm(beta=par, X=X, j=j, p=p, rho=rho, 
                            max_terms=max_terms, tol=tol_Taylor)
        return(ff)
      }
    }
    else {
      # likelihood function, negative binomial model with regression
      ll <- function(par) {
        par.beta <- par[1:length(beta.names)]
        par.k <- par[length(beta.names)+1]
        l <- loglik_negbin_lm(beta=par.beta, kappa=par.k, X=X, j=j, p=p, 
                             max_terms=max_terms, tol=tol_Taylor)
        return(l)
      }
      # score function, negative binomial model with regression
      u <- function(par) {
        par.beta <- par[1:length(beta.names)]
        par.k <- par[length(beta.names)+1]
        uu <- score_negbin_lm(beta=par.beta, kappa=par.k, X=X, j=j, p=p, 
                              h = h_1,
                              max_terms=max_terms, tol=tol_Taylor)
        return(uu)
      }
      # score function, negative binomial model with regression
      FI <- function(par) {
        par.beta <- par[1:length(beta.names)]
        par.k <- par[length(beta.names)+1]
        ff <- Fisher_info_negbin_lm(beta=par.beta, kappa=par.k, X=X, j=j, p=p, 
                              h_1 = h_1, h_2 = h_2,
                              max_terms=max_terms, tol=tol_Taylor)
        return(ff)
      }
    }
  }
  
  # starting values:
  if (is.null(par0)) {
    if (simple.model) {
      cs <- split(j, f=j, drop=TRUE)
      nj <- sapply(cs, length)
      jj <- sapply(cs, unique)
      mu <- 1/sum(nj)*sum(nj*jj)
      beta0 <- init_R0(p=unique(p), rho=unique(rho), mu=mu, tol=tol_R0)
    }
    else {
      beta0 <- init_R0_reg_coef(formula=formula, data=data, p=p, rho=rho, tol=tol_R0)
    }
    if (model=="NegativeBinomial") {
      par0 <- c(beta0, 0)
    }
    else {
      par0 <- beta0
    }
  }
  
  # mle:
  minll <- function(par) -ll(par)
  minu <- function(par) -u(par)
  ctrl <- list(trace=trace, reltol=tol, kkt=FALSE)
  if (is.finite(max_iter)) {
    ctrl[["maxit"]] <- max_iter
  }
  names(par0) <- par.names
  par.hat <- tryCatch(suppressWarnings(optimx::optimx(par=par0, fn = minll, gr = minu, method=method,
                                              hessian=FALSE,
                                              control=ctrl)),
                      error = function(e) e)
  used.method <- new("Optim", method = method,
                              par0 = par0,
                              Taylor_precision = tol_Taylor,
                              max_Taylor_terms = if (max_terms > 0) max_terms else Inf,
                              convergence_precision = tol,
                              max_iterations = max_iter,
                              h_1 = h_1,
                              h_2 = h_2)
  
  if (inherits(par.hat, "error") || par.hat$convcode != 0) {
    par.hat <- rep(NA, length(par0))
  }
  else {
    par.hat <- as.numeric(par.hat[1:length(par0)])
  }
  names(par.hat) <- names(par0)
  
  coef <- list()
  coef[["R0"]] <-if (model=="Poisson") par.hat else par.hat[1:length(par.hat)-1]
  coef[["others"]] <- if (model=="Poisson") numeric() else par.hat[length(par.hat)]
  
  # Akaike and Bayesian information criterion
  ABIC <- information_criterion(theta_mle=par.hat, 
                                loglik=ll, 
                                nr_par=length(par.hat),
                                nr_obs=nrow(data))
  
  # p-values of the parameters
  par_for_p <- which(!is.na(par.hat))
  if (length(par_for_p) > 0) {
    p_vals <- p_values_Wald_test(par_hat = par.hat[par_for_p],
                              Fisher_info_hat = FI(par.hat),
                              H_0 = 0,
                              H_alter = "equal")
  }
  else {
    p_vals <- numeric(0)
  }
  
  mle.fit <- new("MLEfit", coefficients = coef,
                           parameter_names = names(par.hat),
                           AIC = ABIC$AIC,
                           BIC = ABIC$BIC,
                           p_value = p_vals,
                           loglik = ll,
                           score = u,
                           Fisher_info = FI,
                           formula = formula,
                           design_matrix = X,
                           chain_sizes = as.integer(data[[as.character(response)]]),
                           p = as.numeric(p),
                           rho = as.numeric(rho),
                           model = model,
                           data = data,
                           call = match.call(),
                           tol_R0 = tol_R0,
                           optim_method = used.method)
                           
  return(mle.fit)
}