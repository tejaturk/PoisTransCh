init_R0_reg_coef <- function(formula, data, p, rho, tol=1e-3) {
  
  # if p is the same for all chains:
  if (length(p)==1) {
    p <- rep(p, nrow(data))
  }
  # if rho is the same for all chains:
  if (length(rho)==1) {
    rho <- rep(rho, nrow(data))
  }
  
  size <- deparse(formula[[2]]) # column name containing the size of chains
  
  # getting lambda_init for each row:
  lambda_init <- sapply(1:nrow(data), FUN=function(i) init_R0(p = p[i], 
                                                              rho = rho[i], 
                                                              mu = data[i, size],
                                                              tol = tol))
  
  # new chains
  newdf <- data.frame(lambda_init=lambda_init, data)
  
  # updated formula: lambda_init in the response instead of chain size
  new.f <- update.formula(formula, log(lambda_init)~.)
  
  # lm on the updated formula and dataset with initial lambdas:
  beta_lm <- lm(new.f, data = newdf, na.action = na.omit)

  # return the coefficients
  beta_0 <- coefficients(beta_lm)
  return(beta_0)
  
}