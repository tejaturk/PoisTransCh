prof_loglik <- function(par_hat, mle_fit, trace=FALSE) {
  
  # value of the profile-likelihood function at par_hat
  pars_mle <- c(mle_fit@coefficients$R0, mle_fit@coefficients$others)
  fix_par <- names(par_hat)
  nuis_par <- names(pars_mle)[which(!(names(pars_mle) %in% fix_par))]
  prof_lik <- function(par) {
    par_ex <- pars_mle
    if (length(fix_par) > 0) {
      par_ex[fix_par] <- par_hat
    }
    if (length(nuis_par) > 0) {
      par_ex[nuis_par] <- par[nuis_par]
    }
    return(-mle_fit@loglik(par_ex))
  }

  prof_u <- function(par) {
    par_ex <- pars_mle
    if (length(fix_par) > 0) {
      par_ex[fix_par] <- par_hat
    }
    if (length(nuis_par) > 0) {
      par_ex[nuis_par] <- par[nuis_par]
    }
    return(-mle_fit@score(par_ex)[nuis_par, drop=FALSE])
  }
  # maximize the profile likelihood functions
  if (length(nuis_par) > 0) {
    par0 <- pars_mle[nuis_par]
    
    ctrl <- list(reltol=mle_fit@optim_method@convergence_precision, kkt=FALSE,
                 trace=trace)
    if (is.finite(mle_fit@optim_method@max_iterations)) {
      ctrl[["maxit"]] <- mle_fit@optim_method@max_iterations
    }
    prof_loglik_0 <- tryCatch(suppressWarnings(optimx::optimx(par=par0, fn = prof_lik, gr = prof_u, 
                                                              method=mle_fit@optim_method@method,
                                                              hessian=FALSE,
                                                              control=ctrl)),
                              error = function(e) e)
    if (inherits(prof_loglik_0, "error")) {
      prof_loglik_0 <- NA
    }
    else {
      prof_loglik_0 <- -prof_loglik_0$val
    }
  }
  
  else {
    prof_loglik_0 <- -prof_lik(c())
  }
  return(prof_loglik_0)
  
}