score_negbin_lm <- function(beta, kappa, X, j, p, h=1e-6, max_terms=Inf, tol=1e-32) {
  
  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # if p is the same for all chains
  if (length(p)==1) {
    p <- rep(p, nrow(X))
  }
  
  # calculate R0s: exp(x^T beta) for each row of B and k=e^kappa
  R0 <- exp(X%*%beta)
  k <- exp(kappa)

  # the S derivatives
  # the S derivatives
  Sj <- mapply(FUN = function(rr, kk, jj, pp) S_j(j=jj, 
                                                  R0=rr,
                                                  k=kk,
                                                  p=pp, 
                                                  max_terms = max_terms, tol = tol),
               R0, k, j, p)
  # the probability of observing a chain of size 0
  prob0 <- mapply(FUN = function(rr, kk, pp) S_j(j=0,
                                                 R0=rr,
                                                 k=kk,
                                                 p=pp, 
                                                 max_terms = max_terms, tol = tol),
                  R0, k, p)
  # the partial derivatives of the S derivatives
  dSjR0 <- mapply(FUN = function(rr, kk, jj, pp) dS_jdR0(j=jj, 
                                                         R0=rr,
                                                         k=kk,
                                                         p=pp, 
                                                         h=h,
                                                         max_terms = max_terms, tol = tol),
                  R0, k, j, p)
  dSjk <- mapply(FUN = function(rr, kk, jj, pp) dS_jdk(j=jj, 
                                                       R0=rr,
                                                       k=kk,
                                                       p=pp, 
                                                       h=h,
                                                       max_terms = max_terms, tol = tol),
                 R0, k, j, p)
  # the partial derivative of the S0
  dprob0R0 <-  mapply(FUN = function(rr, kk, pp) dS_jdR0(j=0,
                                                         R0=rr,
                                                         k=kk,
                                                         p=pp, 
                                                         h=h,
                                                         max_terms = max_terms, tol = tol),
                      R0, k, p)
  dprob0k <- mapply(FUN = function(rr, kk, pp) dS_jdk(j=0,
                                                      R0=rr,
                                                      k=kk,
                                                      p=pp, 
                                                      h=h,
                                                      max_terms = max_terms, tol = tol),
                    R0, k, p)
  
  # the score
  # R0 component
  uR0 <- array(as.vector((dSjR0/Sj+dprob0R0/(1-prob0))*R0)*X, dim=dim(X))
  # k component
  uk <- array(as.vector(dSjk/Sj + dprob0k/(1-prob0))*k, dim=c(dim(X)[1], 1))
  
  # together
  uu <- array(cbind(uR0, uk), dim=c(dim(X)[1], dim(X)[2]+1))
  u <- array(apply(uu, MARGIN = 2, FUN=sum), dim=c(dim(X)[2]+1))
  dimnames(u)[[1]] <- c(dimnames(X)[[2]], "log(k)")
  
  return(u)
  
}