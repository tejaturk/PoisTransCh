score_pois_1 <- function(beta, j, n_j, p, rho, max_terms=Inf, tol=1e-32) {
  
  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # the probability generating function is defined for lambda = e^beta
  lambda <- exp(beta)
  
  # the R derivatives
  Rj <- sapply(j, R_j, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the probability of observing a chain of size0
  prob0 <- R_j(j=0, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the partial derivatives of the R derivatives
  dRj <- sapply(j, dR_j, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the partial derivative of the R0
  dprob0 <- dR_j(j=0, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  
  # the score
  u <- array(sum(n_j*(dRj/Rj + dprob0/(1-prob0)))*lambda, dim=c(1))
  dimnames(u)[[1]] <- list("log(lambda)")
  
  return(u)
  
}