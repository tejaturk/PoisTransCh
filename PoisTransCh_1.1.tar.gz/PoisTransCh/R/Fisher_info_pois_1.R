Fisher_info_pois_1 <- function(beta, j, n_j, p, rho, max_terms=Inf, tol=1e-32) {
  
  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # the probability generating function is defined for lambda = e^beta
  lambda <- exp(beta)
  
  # the R derivatives
  Rj <- sapply(j, R_j, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the probability of observing a chain of size0
  prob0 <- R_j(j=0, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the partial derivatives of the R derivatives
  dRj <- sapply(j, dR_j, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the partial derivative of the R0
  dprob0 <- dR_j(j=0, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the second partial derivatives of the R derivatives
  d2Rj <- sapply(j, d2R_j, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol)
  # the second partial derivative of the R0
  d2prob0 <- d2R_j(j=0, lambda=lambda, p=p, rho=rho, max_terms=max_terms, tol=tol) 
  
  # the Fisher information matrix
  FI <- -sum(n_j*(((d2Rj/Rj - (dRj/Rj)^2 + d2prob0/(1-prob0) + (dprob0/(1-prob0))^2)*lambda 
                  + dRj/Rj + dprob0/(1-prob0))*lambda))
  # prepare array:
  FI <- array(FI, dim=c(1,1))
  dimnames(FI)[[1]] <- list("(Intercept)")
  dimnames(FI)[[2]] <- list("(Intercept)")
  
  return(FI)
  
}