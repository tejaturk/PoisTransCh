CI_loglik <- function(mle_fit, pars=NULL, alpha=0.95, trace=FALSE, bands=NULL,
                      nr_steps = 6) {
  
  par_hat <- c(mle_fit@coefficients$R0, mle_fit@coefficients$others)
  if (is.null(pars)) {
    pars <- mle_fit@parameter_names
  }
  par_hat <- par_hat[pars]
  
  # Wald confidence intervals for the lower & upper bounds if the bands are missing
  if (is.null(bands)) {
    z <- qnorm((1+alpha)/2)
    
    Fisher_info_hat <- mle_fit@Fisher_info(c(mle_fit@coefficients$R0, mle_fit@coefficients$others))
    # it can be defined for more parameters at once
    inv_FI <- solve(Fisher_info_hat)[names(par_hat), names(par_hat), drop=FALSE]
    diag_inv_FI <- diag(inv_FI)
    
    ci <- mapply(FUN=function(ph, se) ph + c(-1, 1)*z*se,
                 par_hat, sqrt(diag_inv_FI), SIMPLIFY=FALSE)
    
    # return an array
    ci <- array(do.call(rbind, ci), dim=c(length(par_hat), 2))
    dimnames(ci)[[1]] <- as.list(names(par_hat))
    dimnames(ci)[[2]] <- paste(round(c((1-alpha)/2, (1+alpha)/2)*100, digits=2), "%", sep="")
    
    bands <- ci
  }
  
  max_ll <- mle_fit@loglik(c(mle_fit@coefficients$R0, mle_fit@coefficients$others))
  chi_sq <- qchisq(p=alpha, df = 1)
  cis <- sapply(pars, FUN=function(pn) {
    # test function
    lr_fun <- function(pv) {
      ph <- c(pv)
      names(ph) <- pn
      lrt <- 2*max_ll-2*prof_loglik(par_hat=ph,
                             mle_fit=mle_fit,
                             trace=trace) - chi_sq
      return(lrt)
    }
    # search for all roots: -> first lower bound
    lower_limit <- par_hat[pn]-1.5*(par_hat[pn]-bands[pn,1])
    # are the values of a different sign?
    l_v <- lr_fun(lower_limit)
    e_v <- lr_fun(par_hat[pn])
    i <- 1
    while ((is.na(l_v) | sign(l_v)==sign(e_v)) & (i <= nr_steps)) {
      lower_limit <- par_hat[pn]-(1+i*0.5)*(par_hat[pn]-bands[pn,1])
      l_v <- lr_fun(lower_limit)
    }
    low_b <- uniroot(f = lr_fun, interval = c(lower_limit, par_hat[pn]), trace = trace)
    low_b <- low_b$root
    
    # search for all roots: -> upper bound
    upper_limit <- par_hat[pn]+1.5*(bands[pn,2]-par_hat[pn])
    # are the values of a different sign?
    u_v <- lr_fun(upper_limit)
    i <- 1
    while ((is.na(u_v) | sign(u_v)==sign(e_v)) & (i <= nr_steps)) {
      upper_limit <- par_hat[pn]-(1+i*0.5)*(bands[pn,2]-par_hat[pn])
      u_v <- lr_fun(upper_limit)
    }
    up_b <- uniroot(f = lr_fun, interval = c(par_hat[pn], upper_limit), trace = trace)
    up_b <- up_b$root
    
    ci <- array(c(low_b, up_b),dim=c(1, 2))
    dimnames(ci)[[1]] <- as.list(pn)
    dimnames(ci)[[2]] <- paste(round(c((1-alpha)/2, (1+alpha)/2)*100, digits=2), "%", sep="")
    
    return(ci)
  }, simplify = FALSE)
  
  cis <- do.call(rbind, cis)
  return(cis)
  
}