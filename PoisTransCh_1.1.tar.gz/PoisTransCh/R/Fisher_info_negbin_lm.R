Fisher_info_negbin_lm <- function(beta, kappa, X, j, p, 
                                  h_1=1e-6, h_2 = 1e-4, 
                                  max_terms=Inf, tol=1e-32) {
  
  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # if p is the same for all chains
  if (length(p)==1) {
    p <- rep(p, nrow(X))
  }
  
  # calculate R0s: exp(x^T beta) for each row of B and k=e^kappa
  R0 <- exp(X%*%beta)
  k <- exp(kappa)

  # the S derivatives
  # the S derivatives
  Sj <- mapply(FUN = function(rr, kk, jj, pp) S_j(j=jj, 
                                                  R0=rr,
                                                  k=kk,
                                                  p=pp, 
                                                  max_terms = max_terms, tol = tol),
               R0, k, j, p)
  # the probability of observing a chain of size 0
  prob0 <- mapply(FUN = function(rr, kk, pp) S_j(j=0,
                                                 R0=rr,
                                                 k=kk,
                                                 p=pp, 
                                                 max_terms = max_terms, tol = tol),
                  R0, k, p)
  # the partial derivatives of the S derivatives
  dSjR0 <- mapply(FUN = function(rr, kk, jj, pp) dS_jdR0(j=jj, 
                                                         R0=rr,
                                                         k=kk,
                                                         p=pp, 
                                                         h=h_1,
                                                         max_terms = max_terms, tol = tol),
                  R0, k, j, p)
  dSjk <- mapply(FUN = function(rr, kk, jj, pp) dS_jdk(j=jj, 
                                                       R0=rr,
                                                       k=kk,
                                                       p=pp, 
                                                       h=h_1,
                                                       max_terms = max_terms, tol = tol),
                 R0, k, j, p)
  # the partial derivative of the S0
  dprob0R0 <-  mapply(FUN = function(rr, kk, pp) dS_jdR0(j=0,
                                                         R0=rr,
                                                         k=kk,
                                                         p=pp, 
                                                         h=h_1,
                                                         max_terms = max_terms, tol = tol),
                      R0, k, p)
  dprob0k <- mapply(FUN = function(rr, kk, pp) dS_jdk(j=0,
                                                      R0=rr,
                                                      k=kk,
                                                      p=pp, 
                                                      h=h_1,
                                                      max_terms = max_terms, tol = tol),
                    R0, k, p)
  # the second order partial derivatives of the S derivatives
  d2SjR0 <- mapply(FUN = function(rr, kk, jj, pp) d2S_jdR02(j=jj, 
                                                         R0=rr,
                                                         k=kk,
                                                         p=pp, 
                                                         h=h_2,
                                                         max_terms = max_terms, tol = tol),
                   R0, k, j, p)
  d2Sjk <- mapply(FUN = function(rr, kk, jj, pp) d2S_jdk2(j=jj, 
                                                        R0=rr,
                                                        k=kk,
                                                        p=pp, 
                                                        h=h_2,
                                                        max_terms = max_terms, tol = tol),
                  R0, k, j, p)
  d2SjR0k <- mapply(FUN = function(rr, kk, jj, pp) d2S_jdR0dk(j=jj, 
                                                          R0=rr,
                                                          k=kk,
                                                          p=pp, 
                                                          h=h_2,
                                                          max_terms = max_terms, tol = tol),
                    R0, k, j, p)
  # the second partial derivative of the S0
  d2prob0R0 <- mapply(FUN = function(rr, kk, pp) d2S_jdR02(j=0,
                                                        R0=rr,
                                                        k=kk,
                                                        p=pp, 
                                                        h=h_2,
                                                        max_terms = max_terms, tol = tol),
                      R0, k, p)
  d2prob0k <- mapply(FUN = function(rr, kk, pp) d2S_jdk2(j=0,
                                                       R0=rr,
                                                       k=kk,
                                                       p=pp, 
                                                       h=h_2,
                                                       max_terms = max_terms, tol = tol),
                     R0, k, p)
  d2prob0R0k <- mapply(FUN = function(rr, kk, pp) d2S_jdR0dk(j=0,
                                                         R0=rr,
                                                         k=kk,
                                                         p=pp, 
                                                         h=h_2,
                                                         max_terms = max_terms, tol = tol),
                       R0, k, p)
  
  
  # the Fisher information matrix
  # the R0 part
  IIscalar <- ((d2SjR0/Sj - (dSjR0/Sj)^2 + d2prob0R0/(1-prob0) + (dprob0R0/(1-prob0))^2)*R0
               + dSjR0/Sj + dprob0R0/(1-prob0))*R0
  B <- lapply(1:nrow(X), FUN=function(i) {
    t(X[i,,drop=FALSE])%*%X[i,,drop=FALSE]
  })
  II <- mapply(FUN=function(x, XX) x*XX, IIscalar, B, SIMPLIFY=FALSE)
  FI_R0 <- -Reduce('+', II)
  
  # the k part
  FI_k <- -sum(((d2Sjk/Sj - (dSjk/Sj)^2 + d2prob0k/(1-prob0) + (dprob0k/(1-prob0))^2)*k
                     + dSjk/Sj + dprob0k/(1-prob0))*k)
  # prepare array:
  FI_k <- array(FI_k, dim=c(1,1))
  dimnames(FI_k)[[1]] <- list("log(k)")
  dimnames(FI_k)[[2]] <- list("log(k)")
  
  # the mixed part
  FI_R0k <- array(as.vector((d2SjR0k/Sj - dSjR0*dSjk/Sj^2 + d2prob0R0k/(1-prob0) + dprob0R0*dprob0k/(1-prob0)^2)*R0*k)*X, dim=dim(X))
  FI_R0k <- apply(FI_R0k, MARGIN = 2, FUN=sum)
  FI_R0k <- array(FI_R0k, dim=c(ncol(X), 1))
    
  # together:
  FI <- array(rbind(cbind(FI_R0, FI_R0k), cbind(t(FI_R0k), FI_k)), dim=c(dim(FI_R0)[1]+1,dim(FI_R0)[2]+1))
  dimnames(FI)[[1]] <- c(dimnames(FI_R0)[[1]], "log(k)")
  dimnames(FI)[[2]] <- c(dimnames(FI_R0)[[1]], "log(k)")
  
  return(FI)
  
}