extract_clusters <- function(tree, node_groups, group, threshold=0.75) {
  
  # tree: phylogenetic tree
  # nodeGroups: group to which each tip belongs to
  # group: group of the tips of interest (its'name)
  # threshold: the lowest percentage of the cases in cluster to belong to the groups of interest in
  # order to define this as a cluster
  
  # to start: which are the tips of interest?
  ind <- which(node_groups %in% group)
  seqs <- names(node_groups)[ind]
  
  # go through the all the clades systematically
  edges <- as.data.frame(tree$edge)
  names(edges) <- c("ancestor", "descendant")
  row.names(edges) <- seq(1:nrow(edges))
  
  N <- length(tree$tip.label)
  current_nodes <- N + 1
  clusters_nodes <- c()
  descendants <- edges$descendant[which(edges$ancestor %in% current_nodes)]
  while (length(descendants) > 0) {
    cur_clusters <- sapply(descendants, FUN=function(nm) {
      if (nm > N) {
        cl <- ape::extract.clade(tree, node=nm)
        is_cl <- sum(cl$tip.label %in% seqs)/length(cl$tip.label) >= threshold
      }
      else {
        is_cl <- tree$tip.label[nm] %in% seqs
      }
      return(is_cl)
    })
    clusters_nodes <- c(clusters_nodes, descendants[cur_clusters])
    current_nodes <- descendants[!cur_clusters]
    descendants <- edges$descendant[which(edges$ancestor %in% current_nodes)]
  }
  
  # getting the sequences from the clusters
  clusters <- lapply(clusters_nodes, FUN=function(node) {
    if (node <= N) {
      return(tree$tip.label[node])
    }
    else {
      return(ape::extract.clade(tree, node = node)$tip.label)
    }
  })
  names(clusters) <- clusters_nodes
  return(clusters)
}