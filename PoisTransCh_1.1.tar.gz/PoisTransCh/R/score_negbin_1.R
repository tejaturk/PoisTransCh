score_negbin_1 <- function(beta, kappa, j, n_j, p,
                           h = 1e-6,
                           max_terms=Inf, tol=1e-32) {

  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # the probability generating function is defined for R0 = e^beta and k=e^kappa
  R0 <- exp(beta)
  k <- exp(kappa)
  
  # the S derivatives
  Sj <- sapply(j, S_j, R0=R0, k=k, p=p, max_terms=max_terms, tol=tol)
  # the probability of observing a chain of size0
  prob0 <- S_j(j=0, R0=R0, k=k, p=p, max_terms=max_terms, tol=tol) 
  # the partial derivatives of the S derivatives
  dSjR0 <- sapply(j, dS_jdR0, R0=R0, k=k, p=p, h=h, max_terms=max_terms, tol=tol)
  dSjk <- sapply(j, dS_jdk, R0=R0, k=k, p=p, h=h, max_terms=max_terms, tol=tol)
  # the partial derivative of the S0
  dprob0R0 <- dS_jdR0(j=0, R0=R0, k=k, p=p, h=h, max_terms=max_terms, tol=tol)
  dprob0k <- dS_jdk(j=0, R0=R0, k=k, p=p, h=h, max_terms=max_terms, tol=tol)
  
  # the score
  # R0 component
  uR0 <- array(sum(n_j*(dSjR0/Sj + dprob0R0/(1-prob0)))*R0, dim=c(1))
  # k component
  uk <- array(sum(n_j*(dSjk/Sj + dprob0k/(1-prob0)))*k, dim=c(1))
  
  # together
  u <- array(c(uR0, uk), dim=c(2))
  dimnames(u)[[1]] <- c("log(R0)", "log(k)")
  
  return(u)
  
}