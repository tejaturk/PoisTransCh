setGeneric("update_mle", function(mle_fit, new_formula, par0=NULL) standardGeneric("update_mle"))

setMethod("update_mle", signature(mle_fit="MLEfit", new_formula="formula", par0="numeric"),
          function(mle_fit, new_formula, par0) {
            
            new_mle <- mle(formula=new_formula,
                           data=mle_fit@data,
                           p=mle_fit@p,
                           rho=mle_fit@rho,
                           model=mle_fit@model,
                           par0=par0,
                           h_1=mle_fit@optim_method@h_1,
                           h_2=mle_fit@optim_method@h_2,
                           method=mle_fit@optim_method@method,
                           max_terms=mle_fit@optim_method@max_Taylor_terms,
                           tol_Taylor=mle_fit@optim_method@Taylor_precision,
                           max_iter=mle_fit@optim_method@max_iterations,
                           tol=mle_fit@optim_method@convergence_precision,
                           trace=FALSE,
                           tol_R0=mle_fit@tol_R0)
            
            return(new_mle)
            
          })

setMethod("update_mle", signature(mle_fit="MLEfit", new_formula="formula", par0="missing"),
          function(mle_fit, new_formula) {
            
            new_mle <- mle(formula=new_formula,
                           data=mle_fit@data,
                           p=mle_fit@p,
                           rho=mle_fit@rho,
                           model=mle_fit@model,
                           par0=NULL,
                           h_1=mle_fit@optim_method@h_1,
                           h_2=mle_fit@optim_method@h_2,
                           method=mle_fit@optim_method@method,
                           max_terms=mle_fit@optim_method@max_Taylor_terms,
                           tol_Taylor=mle_fit@optim_method@Taylor_precision,
                           max_iter=mle_fit@optim_method@max_iterations,
                           tol=mle_fit@optim_method@convergence_precision,
                           trace=FALSE,
                           tol_R0=mle_fit@tol_R0)
            
            return(new_mle)
            
          })
