Fisher_info_pois_lm <- function(beta, X, j, p, rho, max_terms=Inf, tol=1e-32) {
  
  # to call C++ function, the max_terms should be -1 if infinite
  if (is.infinite(max_terms)) {
    max_terms <- -1
  }
  
  # if p is the same for all chains
  if (length(p)==1) {
    p <- rep(p, nrow(X))
  }
  
  # if rho is the same for all chains
  if (length(rho)==1) {
    rho <- rep(rho, nrow(X))
  }
  
  # calculate lambdas: exp(x^T beta) for each row of B
  lambda <- exp(X%*%beta)
  
  # the R derivatives
  Rj <- mapply(FUN = function(ll, jj, pp, aa) R_j(j=jj, 
                                                  lambda=ll, 
                                                  p=pp, 
                                                  rho=aa,
                                                  max_terms = max_terms, tol = tol),
               lambda, j, p, rho)
  # the probability of observing a chain of size 0
  prob0 <- mapply(FUN = function(ll, pp, aa) R_j(j=0,
                                                 lambda=ll, 
                                                 p=pp, 
                                                 rho=aa,
                                                 max_terms = max_terms, tol = tol),
                  lambda, p, rho)
  # the partial derivatives of the R derivatives
  dRj <- mapply(FUN = function(ll, jj, pp, aa) dR_j(j=jj, 
                                                    lambda=ll, 
                                                    p=pp, 
                                                    rho=aa,
                                                    max_terms = max_terms, tol = tol),
                lambda, j, p, rho)
  # the partial derivative of the R0
  dprob0 <- mapply(FUN = function(ll, pp, aa) dR_j(j=0,
                                                   lambda=ll, 
                                                   p=pp, 
                                                   rho=aa,
                                                   max_terms = max_terms, tol = tol),
                   lambda, p, rho) 
  # the second partial derivatives of the R derivatives
  d2Rj <- mapply(FUN = function(ll, jj, pp, aa) d2R_j(j=jj, 
                                                    lambda=ll, 
                                                    p=pp, 
                                                    rho=aa,
                                                    max_terms = max_terms, tol = tol),
                lambda, j, p, rho)
  # the second partial derivative of the R0
  d2prob0 <- mapply(FUN = function(ll, pp, aa) d2R_j(j=0,
                                                   lambda=ll, 
                                                   p=pp, 
                                                   rho=aa,
                                                   max_terms = max_terms, tol = tol),
                   lambda, p, rho) 
  
  # the Fisher information matrix
  IIscalar <- ((d2Rj/Rj - (dRj/Rj)^2 + d2prob0/(1-prob0) + (dprob0/(1-prob0))^2)*lambda
               + dRj/Rj + dprob0/(1-prob0))*lambda
  B <- lapply(1:nrow(X), FUN=function(i) {
    t(X[i,,drop=FALSE])%*%X[i,,drop=FALSE]
  })
  II <- mapply(FUN=function(x, XX) x*XX, IIscalar, B, SIMPLIFY=FALSE)
  FI <- -Reduce('+', II)
  
  return(FI)
  
}